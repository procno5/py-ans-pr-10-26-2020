# py_ans_10-26-2020
Examples for a Python and Ansible Course

This could be more detailed...
