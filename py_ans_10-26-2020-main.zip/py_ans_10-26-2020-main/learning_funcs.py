

# Adding 33 to any number
def add_33(num):
    result = num + 33
    print(result)
    return result

answer = add_33(11)
print(answer)
add_33(answer)


new_list = [ 5060, "80", 55, "10.0.0.1", "10.20.30.1", "ssh" ]
# When I ssh into IP addresses 10.0.0.1 or 10.20.30.1 I am unable to ping ports 5060, 80, or 55.


